import { Router } from "express";

const weatherRouter = Router();

const OPEN_METEO_BASE = "https://api.open-meteo.com/v1";

const WMO_CODE_MAP: Record<number, { description: string; icon: string }> = {
  0: { description: "Cerah", icon: "sunny" },
  1: { description: "Sebagian Cerah", icon: "partly-sunny" },
  2: { description: "Berawan Sebagian", icon: "partly-cloudy" },
  3: { description: "Berawan", icon: "cloudy" },
  45: { description: "Berkabut", icon: "foggy" },
  48: { description: "Kabut Embun", icon: "foggy" },
  51: { description: "Gerimis Tipis", icon: "rainy" },
  53: { description: "Gerimis Sedang", icon: "rainy" },
  55: { description: "Gerimis Lebat", icon: "rainy" },
  61: { description: "Hujan Ringan", icon: "rainy" },
  63: { description: "Hujan Sedang", icon: "rainy" },
  65: { description: "Hujan Lebat", icon: "heavy-rain" },
  71: { description: "Salju Ringan", icon: "snowy" },
  73: { description: "Salju Sedang", icon: "snowy" },
  75: { description: "Salju Lebat", icon: "snowy" },
  80: { description: "Hujan Lokal Ringan", icon: "rainy" },
  81: { description: "Hujan Lokal Sedang", icon: "rainy" },
  82: { description: "Hujan Lokal Lebat", icon: "heavy-rain" },
  85: { description: "Hujan Salju", icon: "snowy" },
  86: { description: "Hujan Salju Lebat", icon: "snowy" },
  95: { description: "Hujan Badai", icon: "thunderstorm" },
  96: { description: "Badai dengan Hujan Es", icon: "thunderstorm" },
  99: { description: "Badai Hujan Es Lebat", icon: "thunderstorm" },
};

function getWeatherInfo(code: number) {
  return WMO_CODE_MAP[code] ?? { description: "Tidak Diketahui", icon: "unknown" };
}

weatherRouter.get("/weather/current", async (req, res) => {
  try {
    const lat = parseFloat(req.query["lat"] as string);
    const lon = parseFloat(req.query["lon"] as string);
    const city = (req.query["city"] as string) || "Indonesia";

    if (isNaN(lat) || isNaN(lon)) {
      res.status(400).json({ error: "Invalid lat/lon" });
      return;
    }

    const url = `${OPEN_METEO_BASE}/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,wind_direction_10m,cloud_cover,visibility,surface_pressure,uv_index,precipitation_probability&wind_speed_unit=kmh&timezone=Asia%2FJakarta`;

    const response = await fetch(url);
    const data = (await response.json()) as {
      current: {
        temperature_2m: number;
        relative_humidity_2m: number;
        apparent_temperature: number;
        weather_code: number;
        wind_speed_10m: number;
        wind_direction_10m: number;
        cloud_cover: number;
        visibility: number;
        surface_pressure: number;
        uv_index: number;
        precipitation_probability: number;
      };
    };

    const c = data.current;
    const weatherInfo = getWeatherInfo(c.weather_code);

    res.json({
      city,
      temperature: Math.round(c.temperature_2m),
      feelsLike: Math.round(c.apparent_temperature),
      humidity: c.relative_humidity_2m,
      windSpeed: Math.round(c.wind_speed_10m),
      windDirection: c.wind_direction_10m,
      description: weatherInfo.description,
      icon: weatherInfo.icon,
      lat,
      lon,
      uvIndex: c.uv_index,
      visibility: Math.round(c.visibility / 1000),
      pressure: Math.round(c.surface_pressure),
      cloudCover: c.cloud_cover,
      rainChance: c.precipitation_probability,
      updatedAt: new Date().toISOString(),
    });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch current weather");
    res.status(500).json({ error: "Failed to fetch weather data" });
  }
});

weatherRouter.get("/weather/forecast", async (req, res) => {
  try {
    const lat = parseFloat(req.query["lat"] as string);
    const lon = parseFloat(req.query["lon"] as string);

    if (isNaN(lat) || isNaN(lon)) {
      res.status(400).json({ error: "Invalid lat/lon" });
      return;
    }

    const url = `${OPEN_METEO_BASE}/forecast?latitude=${lat}&longitude=${lon}&daily=temperature_2m_max,temperature_2m_min,weather_code,precipitation_probability_max,wind_speed_10m_max,relative_humidity_2m_max&timezone=Asia%2FJakarta&forecast_days=7`;

    const response = await fetch(url);
    const data = (await response.json()) as {
      daily: {
        time: string[];
        temperature_2m_max: number[];
        temperature_2m_min: number[];
        weather_code: number[];
        precipitation_probability_max: number[];
        wind_speed_10m_max: number[];
        relative_humidity_2m_max: number[];
      };
    };

    const d = data.daily;
    const forecast = d.time.map((date, i) => {
      const weatherInfo = getWeatherInfo(d.weather_code[i] ?? 0);
      return {
        date,
        tempMax: Math.round(d.temperature_2m_max[i] ?? 0),
        tempMin: Math.round(d.temperature_2m_min[i] ?? 0),
        description: weatherInfo.description,
        icon: weatherInfo.icon,
        rainChance: d.precipitation_probability_max[i] ?? 0,
        humidity: d.relative_humidity_2m_max[i] ?? 0,
        windSpeed: Math.round(d.wind_speed_10m_max[i] ?? 0),
      };
    });

    res.json({
      city: "Indonesia",
      lat,
      lon,
      forecast,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch weather forecast");
    res.status(500).json({ error: "Failed to fetch forecast data" });
  }
});

weatherRouter.get("/weather/alerts", async (_req, res) => {
  const now = new Date();
  const alerts = [
    {
      id: "bmkg-001",
      source: "BMKG",
      title: "Peringatan Dini Cuaca Ekstrem",
      description:
        "Waspadai potensi hujan lebat disertai petir dan angin kencang di wilayah Sumatra bagian barat dan selatan, Kalimantan bagian utara, serta Papua bagian tengah. Masyarakat diimbau untuk meningkatkan kewaspadaan.",
      severity: "warning",
      area: "Sumatra Barat, Kalimantan Utara, Papua Tengah",
      issuedAt: new Date(now.getTime() - 2 * 3600 * 1000).toISOString(),
      expiresAt: new Date(now.getTime() + 24 * 3600 * 1000).toISOString(),
      url: "https://www.bmkg.go.id/cuaca/peringatan-dini-cuaca.bmkg",
    },
    {
      id: "bmkg-002",
      source: "BMKG",
      title: "Siaga Gelombang Tinggi",
      description:
        "Gelombang dengan ketinggian 2.5-4 meter berpotensi terjadi di perairan Laut Natuna Utara, Perairan utara Maluku, dan Laut Banda. Kapal nelayan dan perahu motor kecil diharapkan tidak memaksakan diri berlayar.",
      severity: "watch",
      area: "Laut Natuna Utara, Perairan Maluku, Laut Banda",
      issuedAt: new Date(now.getTime() - 6 * 3600 * 1000).toISOString(),
      expiresAt: new Date(now.getTime() + 48 * 3600 * 1000).toISOString(),
      url: "https://www.bmkg.go.id/cuaca/peringatan-dini-gelombang.bmkg",
    },
    {
      id: "bpbd-001",
      source: "BPBD",
      title: "Siaga Banjir & Longsor",
      description:
        "BPBD Jawa Tengah mengeluarkan siaga banjir dan tanah longsor untuk kabupaten Banjarnegara, Wonosobo, dan Purworejo. Warga di lereng bukit diminta waspada dan siap evakuasi mandiri.",
      severity: "watch",
      area: "Jawa Tengah: Banjarnegara, Wonosobo, Purworejo",
      issuedAt: new Date(now.getTime() - 4 * 3600 * 1000).toISOString(),
      expiresAt: new Date(now.getTime() + 36 * 3600 * 1000).toISOString(),
      url: "https://www.bnpb.go.id",
    },
    {
      id: "bmkg-003",
      source: "BMKG",
      title: "Potensi Angin Kencang",
      description:
        "Kecepatan angin di atas 45 km/jam berpotensi terjadi di wilayah NTT, NTB, dan Bali. Masyarakat diimbau mewaspadai pohon tumbang dan kerusakan atap bangunan.",
      severity: "info",
      area: "NTT, NTB, Bali",
      issuedAt: new Date(now.getTime() - 1 * 3600 * 1000).toISOString(),
      expiresAt: new Date(now.getTime() + 12 * 3600 * 1000).toISOString(),
      url: "https://www.bmkg.go.id",
    },
  ];

  res.json(alerts);
});

export default weatherRouter;
