import { Router, type IRouter } from "express";
import healthRouter from "./health";
import weatherRouter from "./weather";
import openaiRouter from "./openai";

const router: IRouter = Router();

router.use(healthRouter);
router.use(weatherRouter);
router.use(openaiRouter);

export default router;
