import React, { createContext, useContext } from "react";
import { useWeather } from "@/hooks/useWeather";
import type { WeatherData, ForecastDay, WeatherAlert } from "@/hooks/useWeather";
import type { City } from "@/constants/cities";

interface WeatherContextValue {
  selectedCity: City;
  setSelectedCity: (city: City) => Promise<void>;
  weather: WeatherData | null;
  forecast: ForecastDay[];
  alerts: WeatherAlert[];
  loading: boolean;
  error: string | null;
  refresh: () => void;
}

const WeatherContext = createContext<WeatherContextValue | null>(null);

export function WeatherProvider({ children }: { children: React.ReactNode }) {
  const weatherData = useWeather();

  return (
    <WeatherContext.Provider value={weatherData}>
      {children}
    </WeatherContext.Provider>
  );
}

export function useWeatherContext() {
  const ctx = useContext(WeatherContext);
  if (!ctx) throw new Error("useWeatherContext must be used inside WeatherProvider");
  return ctx;
}
