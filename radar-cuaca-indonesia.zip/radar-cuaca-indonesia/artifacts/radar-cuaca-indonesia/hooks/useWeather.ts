import { useState, useEffect, useCallback, useRef } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { City, DEFAULT_CITY } from "@/constants/cities";
import { checkAndNotifyNewAlerts } from "@/services/notificationService";

const BASE_URL = `https://${process.env["EXPO_PUBLIC_DOMAIN"]}`;

export interface WeatherData {
  city: string;
  temperature: number;
  feelsLike: number;
  humidity: number;
  windSpeed: number;
  windDirection: number;
  description: string;
  icon: string;
  lat: number;
  lon: number;
  uvIndex: number;
  visibility: number;
  pressure: number;
  cloudCover: number;
  rainChance: number;
  updatedAt: string;
}

export interface ForecastDay {
  date: string;
  tempMax: number;
  tempMin: number;
  description: string;
  icon: string;
  rainChance: number;
  humidity: number;
  windSpeed: number;
}

export interface WeatherAlert {
  id: string;
  source: string;
  title: string;
  description: string;
  severity: "info" | "watch" | "warning" | "extreme";
  area: string;
  issuedAt: string;
  expiresAt: string;
  url: string;
}

const SELECTED_CITY_KEY = "selected_city";

export function useWeather() {
  const [selectedCity, setSelectedCityState] = useState<City>(DEFAULT_CITY);
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [forecast, setForecast] = useState<ForecastDay[]>([]);
  const [alerts, setAlerts] = useState<WeatherAlert[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const isFirstLoad = useRef(true);

  useEffect(() => {
    AsyncStorage.getItem(SELECTED_CITY_KEY).then((stored) => {
      if (stored) {
        try {
          setSelectedCityState(JSON.parse(stored) as City);
        } catch {
          // use default
        }
      }
    });
  }, []);

  const setSelectedCity = useCallback(async (city: City) => {
    setSelectedCityState(city);
    await AsyncStorage.setItem(SELECTED_CITY_KEY, JSON.stringify(city));
  }, []);

  const fetchWeather = useCallback(async (city: City) => {
    try {
      setLoading(true);
      setError(null);

      const [weatherRes, forecastRes, alertsRes] = await Promise.all([
        fetch(
          `${BASE_URL}/api/weather/current?lat=${city.lat}&lon=${city.lon}&city=${encodeURIComponent(city.name)}`
        ),
        fetch(`${BASE_URL}/api/weather/forecast?lat=${city.lat}&lon=${city.lon}`),
        fetch(`${BASE_URL}/api/weather/alerts`),
      ]);

      if (weatherRes.ok) {
        const weatherData = (await weatherRes.json()) as WeatherData;
        setWeather({ ...weatherData, city: city.name });
      }

      if (forecastRes.ok) {
        const forecastData = (await forecastRes.json()) as { forecast: ForecastDay[] };
        setForecast(forecastData.forecast || []);
      }

      if (alertsRes.ok) {
        const alertsData = (await alertsRes.json()) as WeatherAlert[];
        const newAlerts = alertsData || [];
        setAlerts(newAlerts);

        if (!isFirstLoad.current && newAlerts.length > 0) {
          checkAndNotifyNewAlerts(newAlerts).catch(() => {});
        }
        if (isFirstLoad.current) {
          isFirstLoad.current = false;
          if (newAlerts.length > 0) {
            checkAndNotifyNewAlerts(newAlerts).catch(() => {});
          }
        }
      }
    } catch {
      setError("Gagal memuat data cuaca. Periksa koneksi internet Anda.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchWeather(selectedCity);
    const interval = setInterval(() => fetchWeather(selectedCity), 3 * 60 * 1000);
    return () => clearInterval(interval);
  }, [selectedCity, fetchWeather]);

  const refresh = useCallback(() => fetchWeather(selectedCity), [selectedCity, fetchWeather]);

  return {
    selectedCity,
    setSelectedCity,
    weather,
    forecast,
    alerts,
    loading,
    error,
    refresh,
  };
}
