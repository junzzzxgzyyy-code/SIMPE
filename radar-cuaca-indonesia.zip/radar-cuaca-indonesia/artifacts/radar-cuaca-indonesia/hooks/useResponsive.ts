import { useWindowDimensions } from "react-native";

export interface ResponsiveInfo {
  width: number;
  height: number;
  isMobile: boolean;
  isTablet: boolean;
  isDesktop: boolean;
  isWide: boolean;
  numColumns: number;
  contentMaxWidth: number;
  horizontalPadding: number;
}

export function useResponsive(): ResponsiveInfo {
  const { width, height } = useWindowDimensions();

  const isMobile = width < 768;
  const isTablet = width >= 768 && width < 1200;
  const isDesktop = width >= 1200;
  const isWide = width >= 768;

  const numColumns = isDesktop ? 3 : isTablet ? 2 : 1;
  const contentMaxWidth = isDesktop ? 1100 : isTablet ? 900 : width;
  const horizontalPadding = isDesktop ? 32 : isTablet ? 24 : 16;

  return {
    width,
    height,
    isMobile,
    isTablet,
    isDesktop,
    isWide,
    numColumns,
    contentMaxWidth,
    horizontalPadding,
  };
}
