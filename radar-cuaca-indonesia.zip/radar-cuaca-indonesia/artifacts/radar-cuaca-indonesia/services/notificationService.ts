import { Platform } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Notifications from "expo-notifications";
import type { WeatherAlert } from "@/hooks/useWeather";

const SEEN_ALERTS_KEY = "seen_alert_ids";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldPlaySound: true,
    shouldSetBadge: true,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

export async function requestNotificationPermission(): Promise<boolean> {
  if (Platform.OS === "web") {
    if (!("Notification" in window)) return false;
    if (Notification.permission === "granted") return true;
    if (Notification.permission === "denied") return false;
    const result = await Notification.requestPermission();
    return result === "granted";
  }

  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  if (existingStatus === "granted") return true;

  const { status } = await Notifications.requestPermissionsAsync();
  return status === "granted";
}

async function getSeenAlertIds(): Promise<Set<string>> {
  try {
    const stored = await AsyncStorage.getItem(SEEN_ALERTS_KEY);
    if (stored) return new Set(JSON.parse(stored) as string[]);
  } catch {
    // ignore
  }
  return new Set();
}

async function markAlertsSeen(ids: string[]): Promise<void> {
  try {
    const existing = await getSeenAlertIds();
    ids.forEach((id) => existing.add(id));
    const arr = Array.from(existing).slice(-200);
    await AsyncStorage.setItem(SEEN_ALERTS_KEY, JSON.stringify(arr));
  } catch {
    // ignore
  }
}

function getSeverityLabel(severity: WeatherAlert["severity"]): string {
  switch (severity) {
    case "extreme": return "🚨 BAHAYA";
    case "warning": return "⚠️ WASPADA";
    case "watch": return "🔔 SIAGA";
    default: return "ℹ️ INFO";
  }
}

async function sendNativeNotification(alert: WeatherAlert): Promise<void> {
  await Notifications.scheduleNotificationAsync({
    content: {
      title: `${getSeverityLabel(alert.severity)} · ${alert.source}`,
      body: `${alert.title}\n${alert.area}`,
      data: { alertId: alert.id },
      sound: true,
    },
    trigger: null,
  });
}

function sendWebNotification(alert: WeatherAlert): void {
  if (!("Notification" in window) || Notification.permission !== "granted") return;
  try {
    new Notification(`${getSeverityLabel(alert.severity)} · ${alert.source}`, {
      body: `${alert.title}\n${alert.area}`,
      icon: "/favicon.png",
      tag: alert.id,
    });
  } catch {
    // ignore
  }
}

export async function checkAndNotifyNewAlerts(alerts: WeatherAlert[]): Promise<void> {
  if (!alerts.length) return;

  const notifiableSeverities: WeatherAlert["severity"][] = ["warning", "extreme", "watch"];
  const notifiable = alerts.filter((a) => notifiableSeverities.includes(a.severity));
  if (!notifiable.length) return;

  const seenIds = await getSeenAlertIds();
  const newAlerts = notifiable.filter((a) => !seenIds.has(a.id));

  if (!newAlerts.length) return;

  await markAlertsSeen(newAlerts.map((a) => a.id));

  for (const alert of newAlerts) {
    if (Platform.OS === "web") {
      sendWebNotification(alert);
    } else {
      await sendNativeNotification(alert);
    }
  }
}

export async function clearSeenAlerts(): Promise<void> {
  await AsyncStorage.removeItem(SEEN_ALERTS_KEY);
}
