export interface City {
  name: string;
  lat: number;
  lon: number;
  province: string;
}

export const INDONESIA_CITIES: City[] = [
  { name: "Jakarta", lat: -6.2088, lon: 106.8456, province: "DKI Jakarta" },
  { name: "Surabaya", lat: -7.2575, lon: 112.7521, province: "Jawa Timur" },
  { name: "Bandung", lat: -6.9175, lon: 107.6191, province: "Jawa Barat" },
  { name: "Medan", lat: 3.5896, lon: 98.6731, province: "Sumatera Utara" },
  { name: "Semarang", lat: -6.9932, lon: 110.4203, province: "Jawa Tengah" },
  { name: "Makassar", lat: -5.1477, lon: 119.4327, province: "Sulawesi Selatan" },
  { name: "Palembang", lat: -2.9761, lon: 104.7754, province: "Sumatera Selatan" },
  { name: "Tangerang", lat: -6.1781, lon: 106.63, province: "Banten" },
  { name: "Depok", lat: -6.4025, lon: 106.7942, province: "Jawa Barat" },
  { name: "Denpasar", lat: -8.6705, lon: 115.2126, province: "Bali" },
  { name: "Pontianak", lat: -0.0263, lon: 109.3425, province: "Kalimantan Barat" },
  { name: "Banjarmasin", lat: -3.3194, lon: 114.5908, province: "Kalimantan Selatan" },
  { name: "Samarinda", lat: -0.5016, lon: 117.1537, province: "Kalimantan Timur" },
  { name: "Manado", lat: 1.4748, lon: 124.842, province: "Sulawesi Utara" },
  { name: "Yogyakarta", lat: -7.7956, lon: 110.3695, province: "DIY" },
  { name: "Malang", lat: -7.9666, lon: 112.6326, province: "Jawa Timur" },
  { name: "Padang", lat: -0.9471, lon: 100.4172, province: "Sumatera Barat" },
  { name: "Pekanbaru", lat: 0.5071, lon: 101.4478, province: "Riau" },
  { name: "Jayapura", lat: -2.5916, lon: 140.669, province: "Papua" },
  { name: "Ambon", lat: -3.6554, lon: 128.1908, province: "Maluku" },
  { name: "Kupang", lat: -10.1772, lon: 123.6071, province: "NTT" },
  { name: "Mataram", lat: -8.583, lon: 116.117, province: "NTB" },
  { name: "Banda Aceh", lat: 5.5477, lon: 95.3239, province: "Aceh" },
  { name: "Balikpapan", lat: -1.2654, lon: 116.8312, province: "Kalimantan Timur" },
];

export const DEFAULT_CITY = INDONESIA_CITIES[0]!;
