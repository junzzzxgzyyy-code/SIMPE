const colors = {
  light: {
    text: "#0d2137",
    tint: "#0096c7",

    background: "#edf6fb",
    foreground: "#0d2137",

    card: "#ffffff",
    cardForeground: "#0d2137",

    primary: "#0096c7",
    primaryForeground: "#ffffff",

    secondary: "#ddf0f9",
    secondaryForeground: "#0077b6",

    muted: "#e0f2f9",
    mutedForeground: "#4a7d9c",

    accent: "#f77f00",
    accentForeground: "#ffffff",

    destructive: "#d62828",
    destructiveForeground: "#ffffff",

    border: "#c5e5f2",
    input: "#ddeef7",

    warn: "#f4a261",
    warnForeground: "#7b2d00",

    success: "#0cad4e",
    successForeground: "#ffffff",

    storm: "#c9184a",
    stormForeground: "#ffffff",
  },

  dark: {
    text: "#e0f4fc",
    tint: "#48cae4",

    background: "#0a1929",
    foreground: "#e0f4fc",

    card: "#0d2338",
    cardForeground: "#e0f4fc",

    primary: "#0096c7",
    primaryForeground: "#ffffff",

    secondary: "#0d2f4a",
    secondaryForeground: "#90d7f0",

    muted: "#0d2f4a",
    mutedForeground: "#4d9ab5",

    accent: "#f77f00",
    accentForeground: "#ffffff",

    destructive: "#e63946",
    destructiveForeground: "#ffffff",

    border: "#0d2f4a",
    input: "#0d2f4a",

    warn: "#f4a261",
    warnForeground: "#7b2d00",

    success: "#2dc653",
    successForeground: "#ffffff",

    storm: "#ff4d6d",
    stormForeground: "#ffffff",
  },

  radius: 12,
};

export default colors;
