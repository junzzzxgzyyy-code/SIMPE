import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { useColors } from "@/hooks/useColors";

interface AlertBadgeProps {
  severity: "info" | "watch" | "warning" | "extreme";
  size?: "sm" | "md";
}

const SEVERITY_LABELS: Record<string, string> = {
  info: "INFO",
  watch: "SIAGA",
  warning: "WASPADA",
  extreme: "BAHAYA",
};

export function AlertBadge({ severity, size = "md" }: AlertBadgeProps) {
  const colors = useColors();

  const bgColors: Record<string, string> = {
    info: colors.primary,
    watch: colors.warn,
    warning: colors.accent,
    extreme: colors.destructive,
  };

  const bg = bgColors[severity] || colors.muted;
  const fontSize = size === "sm" ? 9 : 11;

  return (
    <View style={[styles.badge, { backgroundColor: bg }]}>
      <Text style={[styles.text, { fontSize }]}>{SEVERITY_LABELS[severity] || severity.toUpperCase()}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
    alignSelf: "flex-start",
  },
  text: {
    color: "#fff",
    fontWeight: "700",
    letterSpacing: 0.5,
  },
});
