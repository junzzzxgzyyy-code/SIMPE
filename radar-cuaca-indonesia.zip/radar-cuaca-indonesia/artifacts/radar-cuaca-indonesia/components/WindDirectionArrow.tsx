import React from "react";
import { View, StyleSheet } from "react-native";
import Svg, { Path, Circle } from "react-native-svg";

interface WindDirectionArrowProps {
  degrees: number;
  size?: number;
  color?: string;
  bgColor?: string;
}

export function WindDirectionArrow({
  degrees,
  size = 44,
  color = "#0096c7",
  bgColor = "rgba(0,150,199,0.15)",
}: WindDirectionArrowProps) {
  const center = size / 2;
  const radius = size / 2 - 2;

  return (
    <View style={[styles.container, { width: size, height: size }]}>
      <Svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <Circle cx={center} cy={center} r={radius} fill={bgColor} />
        <Path
          d={`M ${center} ${center - radius + 6} L ${center - 5} ${center + 4} L ${center} ${center + 2} L ${center + 5} ${center + 4} Z`}
          fill={color}
          transform={`rotate(${degrees}, ${center}, ${center})`}
        />
      </Svg>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    justifyContent: "center",
  },
});
