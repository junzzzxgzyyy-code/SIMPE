import React from "react";
import { MaterialCommunityIcons, Ionicons } from "@expo/vector-icons";

interface WeatherIconProps {
  icon: string;
  size?: number;
  color?: string;
}

export function WeatherIcon({ icon, size = 48, color = "#fff" }: WeatherIconProps) {
  switch (icon) {
    case "sunny":
      return <MaterialCommunityIcons name="weather-sunny" size={size} color={color} />;
    case "partly-sunny":
      return <MaterialCommunityIcons name="weather-partly-cloudy" size={size} color={color} />;
    case "partly-cloudy":
      return <MaterialCommunityIcons name="weather-partly-cloudy" size={size} color={color} />;
    case "cloudy":
      return <MaterialCommunityIcons name="weather-cloudy" size={size} color={color} />;
    case "foggy":
      return <MaterialCommunityIcons name="weather-fog" size={size} color={color} />;
    case "rainy":
      return <MaterialCommunityIcons name="weather-rainy" size={size} color={color} />;
    case "heavy-rain":
      return <MaterialCommunityIcons name="weather-pouring" size={size} color={color} />;
    case "thunderstorm":
      return <MaterialCommunityIcons name="weather-lightning-rainy" size={size} color={color} />;
    case "snowy":
      return <MaterialCommunityIcons name="weather-snowy" size={size} color={color} />;
    default:
      return <Ionicons name="cloud-outline" size={size} color={color} />;
  }
}
