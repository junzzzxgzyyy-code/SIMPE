import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Platform,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useColors } from "@/hooks/useColors";
import { useResponsive } from "@/hooks/useResponsive";
import { useWeatherContext } from "@/context/WeatherContext";
import { AlertBadge } from "@/components/AlertBadge";
import type { WeatherAlert } from "@/hooks/useWeather";

const STORM_LEVELS = [
  {
    level: "TD",
    name: "Depresi Tropis",
    windSpeed: "< 63 km/j",
    color: "#48cae4",
    description: "Sistem tekanan rendah dengan angin di bawah kekuatan badai tropis. Dapat membawa hujan lebat.",
  },
  {
    level: "TS",
    name: "Badai Tropis",
    windSpeed: "63–118 km/j",
    color: "#0096c7",
    description: "Sistem sirkulasi atmosfer tertutup dengan angin kencang. Berbahaya bagi nelayan dan penerbangan.",
  },
  {
    level: "Ty 1",
    name: "Topan Kategori 1",
    windSpeed: "119–153 km/j",
    color: "#f4a261",
    description: "Topan lemah. Kerusakan minimal. Pohon kecil tumbang, cabang patah, antena rusak.",
  },
  {
    level: "Ty 2",
    name: "Topan Kategori 2",
    windSpeed: "154–177 km/j",
    color: "#e76f51",
    description: "Topan sedang. Kerusakan sedang. Pohon besar tumbang, atap ringan rusak.",
  },
  {
    level: "Ty 3",
    name: "Topan Kategori 3",
    windSpeed: "178–208 km/j",
    color: "#f77f00",
    description: "Topan besar. Kerusakan besar. Banjir pesisir, jendela pecah, bangunan rusak parah.",
  },
  {
    level: "Ty 4",
    name: "Topan Kategori 4",
    windSpeed: "209–251 km/j",
    color: "#d62828",
    description: "Topan sangat kuat. Kerusakan ekstrem. Evakuasi wajib di zona pesisir.",
  },
  {
    level: "Ty 5",
    name: "Topan Super (Kategori 5)",
    windSpeed: "> 252 km/j",
    color: "#9d0208",
    description: "Topan dahsyat. Kehancuran total pada bangunan. Evakuasi menyeluruh diperlukan.",
  },
];

function formatDate(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleDateString("id-ID", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
}

export default function AlertsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { alerts, loading } = useWeatherContext();
  const { isWide, isDesktop, contentMaxWidth, horizontalPadding } = useResponsive();
  const [expandedAlert, setExpandedAlert] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"alerts" | "storms">("alerts");

  const topInset = Platform.OS === "web" ? (isWide ? 0 : 67) : insets.top;
  const bottomInset = Platform.OS === "web" ? 16 : insets.bottom;

  const maxWidthStyle = isWide
    ? { maxWidth: contentMaxWidth, alignSelf: "center" as const, width: "100%" as const }
    : {};

  const criticalAlerts = alerts.filter((a) => a.severity === "extreme" || a.severity === "warning");
  const infoAlerts = alerts.filter((a) => a.severity === "watch" || a.severity === "info");

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <LinearGradient
        colors={["#d62828", "#e63946"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[styles.header, { paddingTop: topInset + 12, paddingHorizontal: horizontalPadding }]}
      >
        <View style={[styles.headerInner, maxWidthStyle]}>
          <View style={styles.headerRow}>
            <View>
              <Text style={styles.headerTitle}>Peringatan & Badai</Text>
              <Text style={styles.headerSub}>Info BMKG, BPBD, dan Tingkat Badai</Text>
            </View>
            {alerts.length > 0 && (
              <View style={styles.alertBadge}>
                <Text style={styles.alertBadgeText}>{alerts.length}</Text>
              </View>
            )}
          </View>
          <View style={styles.tabs}>
            <TouchableOpacity
              onPress={() => setActiveTab("alerts")}
              style={[styles.tab, activeTab === "alerts" && styles.tabActive]}
            >
              <Ionicons
                name="warning"
                size={14}
                color={activeTab === "alerts" ? "#fff" : "rgba(255,255,255,0.6)"}
              />
              <Text style={[styles.tabText, activeTab === "alerts" && styles.tabTextActive]}>
                Peringatan {alerts.length > 0 ? `(${alerts.length})` : ""}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => setActiveTab("storms")}
              style={[styles.tab, activeTab === "storms" && styles.tabActive]}
            >
              <MaterialCommunityIcons
                name="weather-hurricane"
                size={14}
                color={activeTab === "storms" ? "#fff" : "rgba(255,255,255,0.6)"}
              />
              <Text style={[styles.tabText, activeTab === "storms" && styles.tabTextActive]}>Skala Badai</Text>
            </TouchableOpacity>
          </View>
        </View>
      </LinearGradient>

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={[
          { padding: horizontalPadding, paddingBottom: bottomInset + (isWide ? 24 : 90) },
          isWide && { alignItems: "center" },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={[{ width: "100%" }, maxWidthStyle]}>
          {activeTab === "alerts" && (
            <>
              {alerts.length === 0 && !loading && (
                <View style={styles.emptyState}>
                  <View style={[styles.emptyIconBg, { backgroundColor: colors.secondary }]}>
                    <MaterialCommunityIcons name="shield-check-outline" size={48} color={colors.success} />
                  </View>
                  <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Tidak Ada Peringatan</Text>
                  <Text style={[styles.emptyDesc, { color: colors.mutedForeground }]}>
                    Saat ini tidak ada peringatan cuaca aktif di wilayah Indonesia
                  </Text>
                </View>
              )}

              {criticalAlerts.length > 0 && (
                <>
                  <View style={[styles.subHeader, { borderLeftColor: colors.destructive }]}>
                    <Ionicons name="alert-circle" size={16} color={colors.destructive} />
                    <Text style={[styles.subHeaderText, { color: colors.destructive }]}>
                      Kritis / Waspada ({criticalAlerts.length})
                    </Text>
                  </View>
                  <View style={isDesktop ? styles.alertGrid : undefined}>
                    {criticalAlerts.map((alert) => (
                      <AlertCard
                        key={alert.id}
                        alert={alert}
                        expanded={expandedAlert === alert.id}
                        onToggle={() => setExpandedAlert(expandedAlert === alert.id ? null : alert.id)}
                        colors={colors}
                        isDesktop={isDesktop}
                      />
                    ))}
                  </View>
                </>
              )}

              {infoAlerts.length > 0 && (
                <>
                  <View style={[styles.subHeader, { borderLeftColor: colors.primary, marginTop: criticalAlerts.length ? 16 : 0 }]}>
                    <Ionicons name="information-circle" size={16} color={colors.primary} />
                    <Text style={[styles.subHeaderText, { color: colors.primary }]}>
                      Siaga / Info ({infoAlerts.length})
                    </Text>
                  </View>
                  <View style={isDesktop ? styles.alertGrid : undefined}>
                    {infoAlerts.map((alert) => (
                      <AlertCard
                        key={alert.id}
                        alert={alert}
                        expanded={expandedAlert === alert.id}
                        onToggle={() => setExpandedAlert(expandedAlert === alert.id ? null : alert.id)}
                        colors={colors}
                        isDesktop={isDesktop}
                      />
                    ))}
                  </View>
                </>
              )}

              <View style={[styles.notifInfoCard, { backgroundColor: colors.secondary, borderColor: colors.border }]}>
                <MaterialCommunityIcons name="bell-ring-outline" size={18} color={colors.primary} />
                <Text style={[styles.notifInfoText, { color: colors.primary }]}>
                  Notifikasi otomatis aktif — kamu akan diberitahu saat ada peringatan baru (Siaga, Waspada, atau Bahaya).
                </Text>
              </View>
            </>
          )}

          {activeTab === "storms" && (
            <>
              <View style={[styles.infoCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <MaterialCommunityIcons name="information-outline" size={18} color={colors.primary} />
                <Text style={[styles.infoText, { color: colors.mutedForeground }]}>
                  Indonesia berada di wilayah tropis yang dikelilingi samudra Hindia dan Pasifik.
                  Badai tropis dan subtropis dapat mempengaruhi cuaca di wilayah kepulauan.
                </Text>
              </View>
              <View style={isDesktop ? styles.stormGrid : undefined}>
                {STORM_LEVELS.map((storm) => (
                  <View
                    key={storm.level}
                    style={[
                      styles.stormCard,
                      isDesktop && styles.stormCardGrid,
                      { backgroundColor: colors.card, borderColor: colors.border },
                    ]}
                  >
                    <View style={[styles.stormLevel, { backgroundColor: storm.color }]}>
                      <Text style={styles.stormLevelText}>{storm.level}</Text>
                    </View>
                    <View style={styles.stormInfo}>
                      <Text style={[styles.stormName, { color: colors.foreground }]}>{storm.name}</Text>
                      <View style={[styles.stormWindBadge, { backgroundColor: colors.secondary }]}>
                        <MaterialCommunityIcons name="weather-windy" size={12} color={colors.primary} />
                        <Text style={[styles.stormWind, { color: colors.primary }]}>{storm.windSpeed}</Text>
                      </View>
                      <Text style={[styles.stormDesc, { color: colors.mutedForeground }]}>{storm.description}</Text>
                    </View>
                  </View>
                ))}
              </View>
            </>
          )}
        </View>
      </ScrollView>
    </View>
  );
}

function AlertCard({
  alert, expanded, onToggle, colors, isDesktop,
}: {
  alert: WeatherAlert;
  expanded: boolean;
  onToggle: () => void;
  colors: ReturnType<typeof useColors>;
  isDesktop: boolean;
}) {
  const borderColors = {
    info: colors.primary,
    watch: colors.warn,
    warning: colors.accent,
    extreme: colors.destructive,
  };

  return (
    <TouchableOpacity
      onPress={onToggle}
      style={[
        styles.alertCard,
        isDesktop && styles.alertCardGrid,
        {
          backgroundColor: colors.card,
          borderColor: colors.border,
          borderLeftColor: borderColors[alert.severity] || colors.primary,
        },
      ]}
    >
      <View style={styles.alertCardTop}>
        <View style={styles.alertCardLeft}>
          <AlertBadge severity={alert.severity} size="sm" />
          <Text style={[styles.alertCardSource, { color: colors.primary }]}>{alert.source}</Text>
        </View>
        <Ionicons
          name={expanded ? "chevron-up" : "chevron-down"}
          size={18}
          color={colors.mutedForeground}
        />
      </View>

      <Text style={[styles.alertCardTitle, { color: colors.foreground }]}>{alert.title}</Text>

      <View style={styles.alertCardMeta}>
        <Ionicons name="location-outline" size={12} color={colors.mutedForeground} />
        <Text style={[styles.alertCardArea, { color: colors.mutedForeground }]} numberOfLines={expanded ? undefined : 1}>
          {alert.area}
        </Text>
      </View>

      {expanded && (
        <View style={[styles.alertExpanded, { borderTopColor: colors.border }]}>
          <Text style={[styles.alertDesc, { color: colors.foreground }]}>{alert.description}</Text>
          <View style={styles.alertTimes}>
            <View style={[styles.alertTimeBox, { backgroundColor: colors.secondary }]}>
              <Text style={[styles.alertTimeLabel, { color: colors.mutedForeground }]}>Diterbitkan</Text>
              <Text style={[styles.alertTimeValue, { color: colors.foreground }]}>{formatDate(alert.issuedAt)}</Text>
            </View>
            <View style={[styles.alertTimeBox, { backgroundColor: colors.secondary }]}>
              <Text style={[styles.alertTimeLabel, { color: colors.mutedForeground }]}>Berakhir</Text>
              <Text style={[styles.alertTimeValue, { color: colors.foreground }]}>{formatDate(alert.expiresAt)}</Text>
            </View>
          </View>
        </View>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingBottom: 4 },
  headerInner: {},
  headerRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 16 },
  headerTitle: { fontSize: 24, fontWeight: "700", color: "#fff" },
  headerSub: { fontSize: 13, color: "rgba(255,255,255,0.75)", marginTop: 2 },
  alertBadge: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: "rgba(255,255,255,0.25)",
    alignItems: "center", justifyContent: "center",
  },
  alertBadgeText: { color: "#fff", fontSize: 14, fontWeight: "700" },

  tabs: { flexDirection: "row", marginBottom: -1, gap: 4 },
  tab: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 16, paddingVertical: 9, borderRadius: 8 },
  tabActive: { backgroundColor: "rgba(255,255,255,0.2)" },
  tabText: { color: "rgba(255,255,255,0.6)", fontSize: 13, fontWeight: "600" },
  tabTextActive: { color: "#fff" },

  scroll: { flex: 1 },

  emptyState: { alignItems: "center", paddingVertical: 56, gap: 14 },
  emptyIconBg: { width: 90, height: 90, borderRadius: 45, alignItems: "center", justifyContent: "center" },
  emptyTitle: { fontSize: 18, fontWeight: "700" },
  emptyDesc: { fontSize: 14, textAlign: "center", paddingHorizontal: 32, lineHeight: 22 },

  subHeader: {
    flexDirection: "row", alignItems: "center", gap: 8,
    borderLeftWidth: 3, paddingLeft: 10, marginBottom: 10, paddingVertical: 2,
  },
  subHeaderText: { fontSize: 13, fontWeight: "700" },

  alertGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10, marginBottom: 8 },
  alertCard: {
    borderRadius: 14, borderWidth: 1, borderLeftWidth: 4, marginBottom: 10, padding: 14,
  },
  alertCardGrid: { flex: 1, minWidth: 280, marginBottom: 0 },
  alertCardTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 8 },
  alertCardLeft: { flexDirection: "row", alignItems: "center", gap: 8 },
  alertCardSource: { fontSize: 12, fontWeight: "600" },
  alertCardTitle: { fontSize: 14, fontWeight: "700", marginBottom: 6 },
  alertCardMeta: { flexDirection: "row", alignItems: "center", gap: 4 },
  alertCardArea: { fontSize: 12, flex: 1 },
  alertExpanded: { marginTop: 12, paddingTop: 12, borderTopWidth: 1, gap: 10 },
  alertDesc: { fontSize: 13, lineHeight: 20 },
  alertTimes: { flexDirection: "row", gap: 10 },
  alertTimeBox: { flex: 1, borderRadius: 10, padding: 10 },
  alertTimeLabel: { fontSize: 11, marginBottom: 3 },
  alertTimeValue: { fontSize: 13, fontWeight: "600" },

  notifInfoCard: {
    flexDirection: "row", alignItems: "flex-start", gap: 10,
    padding: 14, borderRadius: 12, borderWidth: 1, marginTop: 16,
  },
  notifInfoText: { flex: 1, fontSize: 13, lineHeight: 20 },

  infoCard: {
    flexDirection: "row", gap: 10, padding: 14, borderRadius: 12,
    borderWidth: 1, marginBottom: 16, alignItems: "flex-start",
  },
  infoText: { flex: 1, fontSize: 13, lineHeight: 20 },

  stormGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  stormCard: {
    flexDirection: "row", borderRadius: 14, borderWidth: 1, marginBottom: 10, overflow: "hidden",
  },
  stormCardGrid: { flex: 1, minWidth: 260, marginBottom: 0 },
  stormLevel: { width: 64, alignItems: "center", justifyContent: "center", paddingVertical: 16 },
  stormLevelText: { color: "#fff", fontWeight: "800", fontSize: 13, textAlign: "center" },
  stormInfo: { flex: 1, padding: 12, gap: 5 },
  stormName: { fontSize: 14, fontWeight: "700" },
  stormWindBadge: { flexDirection: "row", alignItems: "center", gap: 4, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3, alignSelf: "flex-start" },
  stormWind: { fontSize: 12, fontWeight: "600" },
  stormDesc: { fontSize: 12, lineHeight: 18 },
});
