import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Platform,
  useWindowDimensions,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { WebView } from "react-native-webview";

import { useColors } from "@/hooks/useColors";
import { useResponsive } from "@/hooks/useResponsive";
import { useWeatherContext } from "@/context/WeatherContext";
import { WindDirectionArrow } from "@/components/WindDirectionArrow";

type MapLayer = "wind" | "clouds" | "rain" | "temp" | "pressure";

const MAP_LAYERS: { key: MapLayer; label: string; icon: string }[] = [
  { key: "wind", label: "Angin", icon: "weather-windy" },
  { key: "clouds", label: "Awan", icon: "weather-cloudy" },
  { key: "rain", label: "Hujan", icon: "weather-rainy" },
  { key: "temp", label: "Suhu", icon: "thermometer" },
  { key: "pressure", label: "Tekanan", icon: "gauge" },
];

const WINDYCOM_LAYER_MAP: Record<MapLayer, string> = {
  wind: "wind",
  clouds: "clouds",
  rain: "rain",
  temp: "temp",
  pressure: "pressure",
};

function getWindyUrl(lat: number, lon: number, layer: MapLayer): string {
  const windyLayer = WINDYCOM_LAYER_MAP[layer];
  return `https://embed.windy.com/embed.html?type=map&location=coordinates&metricRain=mm&metricTemp=%C2%B0C&metricWind=km%2Fh&zoom=5&overlay=${windyLayer}&product=ecmwf&level=surface&lat=${lat}&lon=${lon}&detailLat=${lat}&detailLon=${lon}&marker=true&message=true`;
}

export default function RadarScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { weather, selectedCity } = useWeatherContext();
  const { isWide, isDesktop, contentMaxWidth, horizontalPadding } = useResponsive();
  const { width } = useWindowDimensions();
  const [activeLayer, setActiveLayer] = useState<MapLayer>("rain");

  const topInset = Platform.OS === "web" ? (isWide ? 0 : 67) : insets.top;
  const bottomInset = Platform.OS === "web" ? 16 : insets.bottom;

  const mapUrl = getWindyUrl(selectedCity.lat, selectedCity.lon, activeLayer);

  const mapHeight = isDesktop ? 560 : isWide ? 420 : width * 0.9;

  function getWindDirectionLabel(degrees: number): string {
    const dirs = ["Utara", "Timur Laut", "Timur", "Tenggara", "Selatan", "Barat Daya", "Barat", "Barat Laut"];
    const idx = Math.round(degrees / 45) % 8;
    return dirs[idx] ?? "Utara";
  }

  const maxWidthStyle = isWide
    ? { maxWidth: contentMaxWidth, alignSelf: "center" as const, width: "100%" as const }
    : {};

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={[
        { paddingBottom: bottomInset + (isWide ? 24 : 90) },
        isWide && { alignItems: "center" },
      ]}
      showsVerticalScrollIndicator={false}
    >
      <View style={[{ width: "100%" }, maxWidthStyle]}>
        <LinearGradient
          colors={["#0096c7", "#48cae4"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={[styles.header, { paddingTop: topInset + 12, paddingHorizontal: horizontalPadding }]}
        >
          <Text style={styles.headerTitle}>Radar Cuaca</Text>
          <Text style={styles.headerSub}>Peta live Indonesia · {selectedCity.name}</Text>
        </LinearGradient>

        <View style={[styles.layerRow, { marginHorizontal: isWide ? 0 : 0 }]}>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={[styles.layerScroll, { paddingHorizontal: horizontalPadding }]}
          >
            {MAP_LAYERS.map((layer) => (
              <TouchableOpacity
                key={layer.key}
                onPress={() => setActiveLayer(layer.key)}
                style={[
                  styles.layerBtn,
                  {
                    backgroundColor: activeLayer === layer.key ? colors.primary : colors.card,
                    borderColor: activeLayer === layer.key ? colors.primary : colors.border,
                  },
                ]}
              >
                <MaterialCommunityIcons
                  name={layer.icon as never}
                  size={18}
                  color={activeLayer === layer.key ? "#fff" : colors.mutedForeground}
                />
                <Text
                  style={[
                    styles.layerLabel,
                    { color: activeLayer === layer.key ? "#fff" : colors.mutedForeground },
                  ]}
                >
                  {layer.label}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        <View
          style={[
            styles.mapContainer,
            {
              borderColor: colors.border,
              height: mapHeight,
              marginHorizontal: isWide ? 0 : 16,
            },
          ]}
        >
          {Platform.OS === "web" ? (
            <View style={styles.webMapFallback}>
              <iframe
                src={mapUrl}
                style={{ width: "100%", height: "100%", border: "none", borderRadius: 16 }}
                title="Peta Cuaca"
              />
            </View>
          ) : (
            <WebView
              source={{ uri: mapUrl }}
              style={styles.webview}
              scrollEnabled
              javaScriptEnabled
              domStorageEnabled
              mediaPlaybackRequiresUserAction={false}
              allowsInlineMediaPlayback
              onError={() => {}}
            />
          )}
        </View>

        {weather && (
          <>
            <View style={[styles.sectionHeader, { paddingHorizontal: isWide ? 0 : 20 }]}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Kondisi Angin Saat Ini</Text>
            </View>

            <View
              style={[
                styles.windCard,
                {
                  backgroundColor: colors.card,
                  borderColor: colors.border,
                  marginHorizontal: isWide ? 0 : 16,
                },
              ]}
            >
              <View style={[styles.windMain, isDesktop && styles.windMainWide]}>
                <WindDirectionArrow
                  degrees={weather.windDirection}
                  size={72}
                  color={colors.primary}
                  bgColor={colors.secondary}
                />
                <View style={styles.windInfo}>
                  <Text style={[styles.windSpeed, { color: colors.foreground }]}>
                    {weather.windSpeed} <Text style={styles.windUnit}>km/jam</Text>
                  </Text>
                  <Text style={[styles.windDir, { color: colors.mutedForeground }]}>
                    Arah {getWindDirectionLabel(weather.windDirection)} ({weather.windDirection}°)
                  </Text>
                </View>

                {isDesktop && (
                  <View style={styles.windExtraStats}>
                    <View style={[styles.windExtraItem, { backgroundColor: colors.secondary }]}>
                      <Ionicons name="water-outline" size={16} color={colors.primary} />
                      <Text style={[styles.windExtraValue, { color: colors.foreground }]}>{weather.cloudCover}%</Text>
                      <Text style={[styles.windExtraLabel, { color: colors.mutedForeground }]}>Awan</Text>
                    </View>
                    <View style={[styles.windExtraItem, { backgroundColor: colors.secondary }]}>
                      <MaterialCommunityIcons name="weather-rainy" size={16} color={colors.primary} />
                      <Text style={[styles.windExtraValue, { color: colors.foreground }]}>{weather.rainChance}%</Text>
                      <Text style={[styles.windExtraLabel, { color: colors.mutedForeground }]}>Hujan</Text>
                    </View>
                    <View style={[styles.windExtraItem, { backgroundColor: colors.secondary }]}>
                      <MaterialCommunityIcons name="gauge" size={16} color={colors.primary} />
                      <Text style={[styles.windExtraValue, { color: colors.foreground }]}>{weather.pressure}</Text>
                      <Text style={[styles.windExtraLabel, { color: colors.mutedForeground }]}>hPa</Text>
                    </View>
                  </View>
                )}
              </View>

              {!isDesktop && (
                <View style={[styles.windStats, { borderTopColor: colors.border }]}>
                  <View style={styles.windStatItem}>
                    <Ionicons name="water-outline" size={16} color={colors.mutedForeground} />
                    <Text style={[styles.windStatValue, { color: colors.foreground }]}>{weather.cloudCover}%</Text>
                    <Text style={[styles.windStatLabel, { color: colors.mutedForeground }]}>Tutupan Awan</Text>
                  </View>
                  <View style={[styles.windStatDivider, { backgroundColor: colors.border }]} />
                  <View style={styles.windStatItem}>
                    <MaterialCommunityIcons name="weather-rainy" size={16} color={colors.mutedForeground} />
                    <Text style={[styles.windStatValue, { color: colors.foreground }]}>{weather.rainChance}%</Text>
                    <Text style={[styles.windStatLabel, { color: colors.mutedForeground }]}>Peluang Hujan</Text>
                  </View>
                  <View style={[styles.windStatDivider, { backgroundColor: colors.border }]} />
                  <View style={styles.windStatItem}>
                    <MaterialCommunityIcons name="gauge" size={16} color={colors.mutedForeground} />
                    <Text style={[styles.windStatValue, { color: colors.foreground }]}>{weather.pressure}</Text>
                    <Text style={[styles.windStatLabel, { color: colors.mutedForeground }]}>hPa</Text>
                  </View>
                </View>
              )}
            </View>
          </>
        )}

        <View style={[styles.sectionHeader, { paddingHorizontal: isWide ? 0 : 20 }]}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Sumber Peta</Text>
        </View>
        <View
          style={[
            styles.sourceCard,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
              marginHorizontal: isWide ? 0 : 16,
              flexDirection: isDesktop ? "row" : "column",
            },
          ]}
        >
          <SourceItem icon="earth" label="Windy.com" desc="Radar angin & cuaca real-time" colors={colors} isDesktop={isDesktop} />
          <SourceItem icon="weather-lightning-rainy" label="ECMWF" desc="Model cuaca global presisi tinggi" colors={colors} isDesktop={isDesktop} />
          <SourceItem icon="satellite-variant" label="Open-Meteo" desc="Data cuaca open-source global" colors={colors} isDesktop={isDesktop} />
        </View>
      </View>
    </ScrollView>
  );
}

function SourceItem({
  icon, label, desc, colors, isDesktop,
}: {
  icon: string; label: string; desc: string;
  colors: ReturnType<typeof useColors>; isDesktop: boolean;
}) {
  return (
    <View
      style={[
        styles.sourceItem,
        { borderBottomColor: colors.border },
        isDesktop && { flex: 1, borderBottomWidth: 0 },
      ]}
    >
      <View style={[styles.sourceIcon, { backgroundColor: colors.secondary }]}>
        <MaterialCommunityIcons name={icon as never} size={20} color={colors.primary} />
      </View>
      <View style={styles.sourceText}>
        <Text style={[styles.sourceLabel, { color: colors.foreground }]}>{label}</Text>
        <Text style={[styles.sourceDesc, { color: colors.mutedForeground }]}>{desc}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingBottom: 20 },
  headerTitle: { fontSize: 26, fontWeight: "700", color: "#fff" },
  headerSub: { fontSize: 13, color: "rgba(255,255,255,0.75)", marginTop: 4 },

  layerRow: { marginTop: 16 },
  layerScroll: { gap: 8 },
  layerBtn: {
    flexDirection: "row", alignItems: "center", gap: 6,
    paddingHorizontal: 14, paddingVertical: 8,
    borderRadius: 20, borderWidth: 1,
  },
  layerLabel: { fontSize: 13, fontWeight: "600" },

  mapContainer: {
    marginTop: 12, borderRadius: 16, overflow: "hidden", borderWidth: 1,
  },
  webMapFallback: { flex: 1 },
  webview: { flex: 1 },

  sectionHeader: { marginTop: 20, marginBottom: 10 },
  sectionTitle: { fontSize: 17, fontWeight: "700" },

  windCard: { borderRadius: 16, borderWidth: 1, overflow: "hidden" },
  windMain: { flexDirection: "row", alignItems: "center", gap: 20, padding: 20 },
  windMainWide: { gap: 28, justifyContent: "space-between" },
  windInfo: { flex: 1 },
  windSpeed: { fontSize: 36, fontWeight: "700" },
  windUnit: { fontSize: 16, fontWeight: "400" },
  windDir: { fontSize: 14, marginTop: 4 },

  windExtraStats: { flexDirection: "row", gap: 10 },
  windExtraItem: {
    alignItems: "center", borderRadius: 12, padding: 12, gap: 4, minWidth: 70,
  },
  windExtraValue: { fontSize: 16, fontWeight: "700" },
  windExtraLabel: { fontSize: 11 },

  windStats: { flexDirection: "row", borderTopWidth: 1, paddingVertical: 14 },
  windStatItem: { flex: 1, alignItems: "center", gap: 4 },
  windStatDivider: { width: 1 },
  windStatValue: { fontSize: 16, fontWeight: "700" },
  windStatLabel: { fontSize: 11 },

  sourceCard: { borderRadius: 16, borderWidth: 1, overflow: "hidden" },
  sourceItem: {
    flexDirection: "row", alignItems: "center", gap: 12, padding: 14, borderBottomWidth: 1,
  },
  sourceIcon: { width: 40, height: 40, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  sourceText: { flex: 1 },
  sourceLabel: { fontSize: 14, fontWeight: "600" },
  sourceDesc: { fontSize: 12, marginTop: 2 },
});
