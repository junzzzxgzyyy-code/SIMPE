import { BlurView } from "expo-blur";
import { Tabs, usePathname, useRouter } from "expo-router";
import { MaterialCommunityIcons, Ionicons } from "@expo/vector-icons";
import React from "react";
import { Platform, StyleSheet, View, Text, TouchableOpacity } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useColors } from "@/hooks/useColors";
import { useResponsive } from "@/hooks/useResponsive";

const TAB_ITEMS = [
  {
    name: "index",
    path: "/",
    label: "Cuaca",
    iconDefault: "weather-partly-cloudy" as const,
    ionicon: "partly-sunny-outline" as const,
  },
  {
    name: "radar",
    path: "/radar",
    label: "Radar",
    iconDefault: "radar" as const,
    ionicon: "radio-outline" as const,
  },
  {
    name: "alerts",
    path: "/alerts",
    label: "Peringatan",
    iconDefault: "alert-circle-outline" as const,
    ionicon: "warning-outline" as const,
  },
  {
    name: "chat",
    path: "/chat",
    label: "AI Chat",
    iconDefault: "chat-processing-outline" as const,
    ionicon: "chatbubble-outline" as const,
  },
] as const;

function DesktopSidebar() {
  const colors = useColors();
  const router = useRouter();
  const pathname = usePathname();
  const insets = useSafeAreaInsets();

  return (
    <View
      style={[
        styles.sidebar,
        {
          backgroundColor: colors.card,
          borderRightColor: colors.border,
          paddingTop: insets.top + 16,
          paddingBottom: insets.bottom + 16,
        },
      ]}
    >
      <View style={styles.sidebarLogo}>
        <View style={[styles.sidebarLogoIcon, { backgroundColor: colors.primary }]}>
          <MaterialCommunityIcons name="weather-lightning-rainy" size={22} color="#fff" />
        </View>
        <View>
          <Text style={[styles.sidebarLogoTitle, { color: colors.foreground }]}>Radar Cuaca</Text>
          <Text style={[styles.sidebarLogoSub, { color: colors.mutedForeground }]}>Indonesia</Text>
        </View>
      </View>

      <View style={styles.sidebarNav}>
        {TAB_ITEMS.map((tab) => {
          const isActive =
            tab.name === "index"
              ? pathname === "/" || pathname === "/index"
              : pathname.startsWith(tab.path);
          return (
            <TouchableOpacity
              key={tab.name}
              onPress={() => router.push(tab.path)}
              style={[
                styles.sidebarItem,
                {
                  backgroundColor: isActive ? colors.primary : "transparent",
                },
              ]}
            >
              <MaterialCommunityIcons
                name={tab.iconDefault}
                size={20}
                color={isActive ? "#fff" : colors.mutedForeground}
              />
              <Text
                style={[
                  styles.sidebarLabel,
                  { color: isActive ? "#fff" : colors.mutedForeground },
                ]}
              >
                {tab.label}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>

      <View style={[styles.sidebarFooter, { borderTopColor: colors.border }]}>
        <View style={[styles.sidebarBadge, { backgroundColor: colors.secondary }]}>
          <MaterialCommunityIcons name="satellite-uplink" size={14} color={colors.primary} />
          <Text style={[styles.sidebarBadgeText, { color: colors.primary }]}>Data Real-time</Text>
        </View>
      </View>
    </View>
  );
}

function ClassicTabLayout() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { isWide } = useResponsive();

  const tabBarHidden = isWide;

  return (
    <View style={{ flex: 1, flexDirection: isWide ? "row" : "column" }}>
      {isWide && <DesktopSidebar />}
      <View style={{ flex: 1 }}>
        <Tabs
          screenOptions={{
            tabBarActiveTintColor: colors.primary,
            tabBarInactiveTintColor: colors.mutedForeground,
            headerShown: false,
            tabBarStyle: tabBarHidden
              ? { display: "none" }
              : {
                  position: "absolute",
                  backgroundColor:
                    Platform.OS === "ios" ? "transparent" : colors.card,
                  borderTopWidth: 1,
                  borderTopColor: colors.border,
                  elevation: 0,
                  paddingBottom: insets.bottom,
                  height: 56 + insets.bottom,
                },
            tabBarBackground: () =>
              Platform.OS === "ios" && !tabBarHidden ? (
                <BlurView
                  intensity={80}
                  tint="light"
                  style={StyleSheet.absoluteFill}
                />
              ) : null,
            tabBarLabelStyle: { fontSize: 11, fontWeight: "600", marginBottom: 4 },
          }}
        >
          <Tabs.Screen
            name="index"
            options={{
              title: "Cuaca",
              tabBarIcon: ({ color }) => (
                <MaterialCommunityIcons name="weather-partly-cloudy" size={24} color={color} />
              ),
            }}
          />
          <Tabs.Screen
            name="radar"
            options={{
              title: "Radar",
              tabBarIcon: ({ color }) => (
                <MaterialCommunityIcons name="radar" size={24} color={color} />
              ),
            }}
          />
          <Tabs.Screen
            name="alerts"
            options={{
              title: "Peringatan",
              tabBarIcon: ({ color }) => (
                <Ionicons name="warning-outline" size={24} color={color} />
              ),
            }}
          />
          <Tabs.Screen
            name="chat"
            options={{
              title: "AI Chat",
              tabBarIcon: ({ color }) => (
                <Ionicons name="chatbubble-outline" size={24} color={color} />
              ),
            }}
          />
        </Tabs>
      </View>
    </View>
  );
}

export default function TabLayout() {
  return <ClassicTabLayout />;
}

const styles = StyleSheet.create({
  sidebar: {
    width: 220,
    borderRightWidth: 1,
    flexDirection: "column",
    paddingHorizontal: 16,
  },
  sidebarLogo: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    marginBottom: 28,
  },
  sidebarLogoIcon: {
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  sidebarLogoTitle: { fontSize: 16, fontWeight: "700" },
  sidebarLogoSub: { fontSize: 11, marginTop: 1 },
  sidebarNav: { flex: 1, gap: 4 },
  sidebarItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderRadius: 12,
  },
  sidebarLabel: { fontSize: 14, fontWeight: "600" },
  sidebarFooter: {
    borderTopWidth: 1,
    paddingTop: 16,
  },
  sidebarBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    padding: 10,
    borderRadius: 10,
  },
  sidebarBadgeText: { fontSize: 12, fontWeight: "600" },
});
