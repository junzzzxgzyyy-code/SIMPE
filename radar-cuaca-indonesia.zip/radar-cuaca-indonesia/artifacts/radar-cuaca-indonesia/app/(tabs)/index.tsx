import React, { useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  TouchableOpacity,
  ActivityIndicator,
  Platform,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";

import { useColors } from "@/hooks/useColors";
import { useResponsive } from "@/hooks/useResponsive";
import { useWeatherContext } from "@/context/WeatherContext";
import { WeatherIcon } from "@/components/WeatherIcon";
import { WindDirectionArrow } from "@/components/WindDirectionArrow";
import { AlertBadge } from "@/components/AlertBadge";

function getWindDirectionLabel(degrees: number): string {
  const dirs = ["U", "TL", "T", "TG", "S", "BD", "B", "BL"];
  const idx = Math.round(degrees / 45) % 8;
  return dirs[idx] ?? "U";
}

function getUVLabel(uv: number): string {
  if (uv <= 2) return "Rendah";
  if (uv <= 5) return "Sedang";
  if (uv <= 7) return "Tinggi";
  if (uv <= 10) return "Sangat Tinggi";
  return "Ekstrem";
}

function getUVColor(uv: number, colors: ReturnType<typeof useColors>): string {
  if (uv <= 2) return colors.success;
  if (uv <= 5) return colors.accent;
  if (uv <= 7) return colors.warn;
  if (uv <= 10) return colors.destructive;
  return colors.storm;
}

function formatTime(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" });
}

function formatDay(dateStr: string): string {
  const d = new Date(dateStr);
  return d.toLocaleDateString("id-ID", { weekday: "short", day: "numeric" });
}

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { weather, forecast, alerts, loading, error, refresh, selectedCity } = useWeatherContext();
  const { isWide, isDesktop, isTablet, contentMaxWidth, horizontalPadding } = useResponsive();
  const scrollRef = useRef<ScrollView>(null);

  const topInset = Platform.OS === "web" ? (isWide ? 0 : 67) : insets.top;
  const bottomInset = Platform.OS === "web" ? 16 : insets.bottom;

  if (loading && !weather) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: colors.background }]}>
        <MaterialCommunityIcons name="weather-cloudy-arrow-right" size={56} color={colors.primary} />
        <ActivityIndicator size="large" color={colors.primary} style={{ marginTop: 16 }} />
        <Text style={[styles.loadingText, { color: colors.mutedForeground }]}>Memuat data cuaca...</Text>
      </View>
    );
  }

  if (error && !weather) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: colors.background }]}>
        <Ionicons name="cloud-offline-outline" size={56} color={colors.destructive} />
        <Text style={[styles.errorText, { color: colors.foreground }]}>Gagal memuat data</Text>
        <Text style={[styles.errorSub, { color: colors.mutedForeground }]}>{error}</Text>
        <TouchableOpacity style={[styles.retryBtn, { backgroundColor: colors.primary }]} onPress={refresh}>
          <Text style={{ color: "#fff", fontWeight: "600" }}>Coba Lagi</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const outerPad = { paddingHorizontal: horizontalPadding };
  const maxWidthStyle = isWide ? { maxWidth: contentMaxWidth, alignSelf: "center" as const, width: "100%" as const } : {};

  return (
    <ScrollView
      ref={scrollRef}
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={[
        { paddingBottom: bottomInset + (isWide ? 24 : 90) },
        isWide && { alignItems: "center" },
      ]}
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl refreshing={loading} onRefresh={refresh} tintColor={colors.primary} />
      }
    >
      <View style={[{ width: "100%" }, maxWidthStyle]}>
        <LinearGradient
          colors={["#0096c7", "#48cae4"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={[
            styles.heroCard,
            isWide && styles.heroCardWide,
            { paddingTop: topInset + (isWide ? 24 : 16) },
          ]}
        >
          <View style={[styles.heroHeader, isWide && styles.heroHeaderWide]}>
            <View>
              <View style={styles.locationRow}>
                <Ionicons name="location-sharp" size={16} color="rgba(255,255,255,0.9)" />
                <Text style={styles.cityName}>{selectedCity.name}</Text>
              </View>
              <Text style={styles.province}>{selectedCity.province}</Text>
            </View>
            <TouchableOpacity style={styles.cityPickerBtn} onPress={() => router.push("/cities")}>
              <Ionicons name="list-outline" size={20} color="#fff" />
              {isWide && <Text style={styles.cityPickerText}>Ganti Kota</Text>}
            </TouchableOpacity>
          </View>

          {weather && (
            <>
              <View style={[styles.heroMain, isWide && styles.heroMainWide]}>
                <WeatherIcon icon={weather.icon} size={isDesktop ? 100 : 80} color="rgba(255,255,255,0.95)" />
                <View style={styles.heroTempBlock}>
                  <Text style={[styles.heroTemp, isWide && { fontSize: 80 }]}>{weather.temperature}°</Text>
                  <Text style={styles.heroDesc}>{weather.description}</Text>
                  <Text style={styles.heroFeels}>Terasa {weather.feelsLike}°C</Text>
                </View>
              </View>

              <View style={styles.heroStats}>
                <View style={styles.heroStat}>
                  <Ionicons name="water-outline" size={18} color="rgba(255,255,255,0.8)" />
                  <Text style={styles.heroStatValue}>{weather.humidity}%</Text>
                  <Text style={styles.heroStatLabel}>Lembab</Text>
                </View>
                <View style={styles.heroDivider} />
                <View style={styles.heroStat}>
                  <View style={styles.windRow}>
                    <WindDirectionArrow
                      degrees={weather.windDirection}
                      size={20}
                      color="rgba(255,255,255,0.9)"
                      bgColor="rgba(255,255,255,0.15)"
                    />
                    <Text style={[styles.heroStatValue, { marginLeft: 4 }]}>{weather.windSpeed}</Text>
                    <Text style={styles.heroStatLabel2}> km/j</Text>
                  </View>
                  <Text style={styles.heroStatLabel}>Angin {getWindDirectionLabel(weather.windDirection)}</Text>
                </View>
                <View style={styles.heroDivider} />
                <View style={styles.heroStat}>
                  <MaterialCommunityIcons name="weather-rainy" size={18} color="rgba(255,255,255,0.8)" />
                  <Text style={styles.heroStatValue}>{weather.rainChance}%</Text>
                  <Text style={styles.heroStatLabel}>Hujan</Text>
                </View>
              </View>
            </>
          )}
          <Text style={styles.updatedAt}>
            Diperbarui {weather ? formatTime(weather.updatedAt) : "--"}
          </Text>
        </LinearGradient>

        {weather && (
          <View
            style={[
              styles.detailGrid,
              {
                backgroundColor: colors.card,
                borderColor: colors.border,
                marginHorizontal: isWide ? 0 : 16,
                marginTop: 16,
              },
            ]}
          >
            <DetailItem
              icon="sunny-outline"
              iconLib="Ionicons"
              label="Indeks UV"
              value={`${weather.uvIndex} · ${getUVLabel(weather.uvIndex)}`}
              valueColor={getUVColor(weather.uvIndex, colors)}
              colors={colors}
            />
            <DetailItem
              icon="eye-outline"
              iconLib="Ionicons"
              label="Jarak Pandang"
              value={`${weather.visibility} km`}
              colors={colors}
            />
            <DetailItem
              icon="speedometer-outline"
              iconLib="Ionicons"
              label="Tekanan"
              value={`${weather.pressure} hPa`}
              colors={colors}
            />
            <DetailItem
              icon="cloud-outline"
              iconLib="Ionicons"
              label="Tutupan Awan"
              value={`${weather.cloudCover}%`}
              colors={colors}
            />
          </View>
        )}

        <View style={[styles.sectionHeader, isWide && { marginHorizontal: 0 }]}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Prakiraan 7 Hari</Text>
        </View>

        {isDesktop ? (
          <View style={styles.forecastGrid}>
            {forecast.map((day, idx) => (
              <View
                key={day.date}
                style={[styles.forecastGridCard, { backgroundColor: colors.card, borderColor: colors.border }]}
              >
                <Text style={[styles.forecastGridDay, { color: colors.mutedForeground }]}>
                  {idx === 0 ? "Hari ini" : formatDay(day.date)}
                </Text>
                <WeatherIcon icon={day.icon} size={32} color={colors.primary} />
                <Text style={[styles.forecastGridDesc, { color: colors.foreground }]} numberOfLines={2}>
                  {day.description}
                </Text>
                <View style={styles.forecastGridTemps}>
                  <Text style={[styles.forecastTempMax, { color: colors.foreground }]}>{day.tempMax}°</Text>
                  <Text style={[styles.forecastTempMin, { color: colors.mutedForeground }]}>{day.tempMin}°</Text>
                </View>
                <View style={[styles.forecastGridRain, { backgroundColor: colors.secondary }]}>
                  <MaterialCommunityIcons name="weather-rainy" size={12} color={colors.primary} />
                  <Text style={[styles.forecastGridRainText, { color: colors.primary }]}>{day.rainChance}%</Text>
                </View>
              </View>
            ))}
          </View>
        ) : (
          <View
            style={[
              styles.forecastCard,
              {
                backgroundColor: colors.card,
                borderColor: colors.border,
                marginHorizontal: isWide ? 0 : 16,
              },
            ]}
          >
            {forecast.map((day, idx) => (
              <View key={day.date}>
                {idx > 0 && <View style={[styles.forecastDivider, { backgroundColor: colors.border }]} />}
                <View style={styles.forecastRow}>
                  <Text style={[styles.forecastDay, { color: colors.mutedForeground }]}>
                    {idx === 0 ? "Hari ini" : formatDay(day.date)}
                  </Text>
                  <View style={styles.forecastMiddle}>
                    <WeatherIcon icon={day.icon} size={22} color={colors.primary} />
                    <Text style={[styles.forecastDesc, { color: colors.foreground }]} numberOfLines={1}>
                      {day.description}
                    </Text>
                  </View>
                  <View style={styles.forecastRight}>
                    <Text style={[styles.forecastTempMax, { color: colors.foreground }]}>{day.tempMax}°</Text>
                    <Text style={[styles.forecastTempMin, { color: colors.mutedForeground }]}>{day.tempMin}°</Text>
                  </View>
                </View>
              </View>
            ))}
          </View>
        )}

        {alerts.length > 0 && (
          <>
            <View
              style={[
                styles.sectionHeader,
                isWide && { marginHorizontal: 0 },
              ]}
            >
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Peringatan Aktif</Text>
              <View style={[styles.alertCount, { backgroundColor: colors.destructive }]}>
                <Text style={styles.alertCountText}>{alerts.length}</Text>
              </View>
            </View>
            <View style={isDesktop ? styles.alertsGrid : undefined}>
              {alerts.slice(0, isDesktop ? 4 : 2).map((alert) => (
                <TouchableOpacity
                  key={alert.id}
                  style={[
                    styles.alertCard,
                    isDesktop && styles.alertCardGrid,
                    {
                      backgroundColor: colors.card,
                      borderColor: colors.border,
                      marginHorizontal: isWide ? 0 : 16,
                    },
                  ]}
                  onPress={() => router.push("/alerts")}
                >
                  <View style={styles.alertTop}>
                    <AlertBadge severity={alert.severity} />
                    <Text style={[styles.alertSource, { color: colors.primary }]}>{alert.source}</Text>
                  </View>
                  <Text style={[styles.alertTitle, { color: colors.foreground }]}>{alert.title}</Text>
                  <Text style={[styles.alertArea, { color: colors.mutedForeground }]} numberOfLines={1}>
                    <Ionicons name="location-outline" size={12} /> {alert.area}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
            {alerts.length > 2 && (
              <TouchableOpacity
                style={[
                  styles.viewAllBtn,
                  {
                    borderColor: colors.border,
                    marginHorizontal: isWide ? 0 : 16,
                    backgroundColor: colors.card,
                  },
                ]}
                onPress={() => router.push("/alerts")}
              >
                <Text style={[styles.viewAllText, { color: colors.primary }]}>
                  Lihat semua {alerts.length} peringatan
                </Text>
                <Ionicons name="chevron-forward" size={16} color={colors.primary} />
              </TouchableOpacity>
            )}
          </>
        )}
      </View>
    </ScrollView>
  );
}

interface DetailItemProps {
  icon: string;
  iconLib: "Ionicons" | "MaterialCommunityIcons";
  label: string;
  value: string;
  valueColor?: string;
  colors: ReturnType<typeof useColors>;
}

function DetailItem({ icon, iconLib, label, value, valueColor, colors }: DetailItemProps) {
  return (
    <View style={[styles.detailItem, { borderColor: colors.border }]}>
      {iconLib === "Ionicons" ? (
        <Ionicons name={icon as never} size={20} color={colors.mutedForeground} />
      ) : (
        <MaterialCommunityIcons name={icon as never} size={20} color={colors.mutedForeground} />
      )}
      <Text style={[styles.detailValue, { color: valueColor || colors.foreground }]}>{value}</Text>
      <Text style={[styles.detailLabel, { color: colors.mutedForeground }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loadingContainer: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12 },
  loadingText: { fontSize: 15, marginTop: 8 },
  errorText: { fontSize: 18, fontWeight: "700", marginTop: 12 },
  errorSub: { fontSize: 14, textAlign: "center", paddingHorizontal: 32, marginTop: 4 },
  retryBtn: { marginTop: 20, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 10 },

  heroCard: { paddingHorizontal: 20, paddingBottom: 24 },
  heroCardWide: { borderRadius: 20, marginHorizontal: 0, marginTop: 0 },
  heroHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 },
  heroHeaderWide: { marginBottom: 24 },
  locationRow: { flexDirection: "row", alignItems: "center", gap: 4 },
  cityName: { fontSize: 22, fontWeight: "700", color: "#fff" },
  province: { fontSize: 13, color: "rgba(255,255,255,0.75)", marginTop: 2 },
  cityPickerBtn: {
    flexDirection: "row", alignItems: "center", gap: 6,
    paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20,
    backgroundColor: "rgba(255,255,255,0.2)",
  },
  cityPickerText: { color: "#fff", fontSize: 13, fontWeight: "600" },

  heroMain: { flexDirection: "row", alignItems: "center", gap: 24, marginBottom: 24 },
  heroMainWide: { gap: 32, marginBottom: 28 },
  heroTempBlock: {},
  heroTemp: { fontSize: 64, fontWeight: "200", color: "#fff", lineHeight: 68 },
  heroDesc: { fontSize: 17, color: "rgba(255,255,255,0.9)", fontWeight: "500", marginTop: 2 },
  heroFeels: { fontSize: 13, color: "rgba(255,255,255,0.7)", marginTop: 4 },

  heroStats: {
    flexDirection: "row", justifyContent: "space-around",
    backgroundColor: "rgba(255,255,255,0.18)",
    borderRadius: 16, paddingVertical: 12, paddingHorizontal: 8,
  },
  heroStat: { alignItems: "center", flex: 1, gap: 4 },
  heroStatValue: { fontSize: 16, fontWeight: "700", color: "#fff" },
  heroStatLabel: { fontSize: 11, color: "rgba(255,255,255,0.75)" },
  heroStatLabel2: { fontSize: 11, color: "rgba(255,255,255,0.75)" },
  heroDivider: { width: 1, backgroundColor: "rgba(255,255,255,0.2)", marginVertical: 4 },
  windRow: { flexDirection: "row", alignItems: "center" },
  updatedAt: { fontSize: 11, color: "rgba(255,255,255,0.65)", marginTop: 12, textAlign: "right" },

  detailGrid: {
    borderRadius: 16, borderWidth: 1, flexDirection: "row", flexWrap: "wrap",
  },
  detailItem: {
    width: "50%", padding: 16, alignItems: "center", gap: 4,
    borderRightWidth: 1, borderBottomWidth: 1,
  },
  detailValue: { fontSize: 16, fontWeight: "700" },
  detailLabel: { fontSize: 11 },

  sectionHeader: {
    flexDirection: "row", alignItems: "center",
    paddingHorizontal: 20, marginTop: 20, marginBottom: 10, gap: 8,
  },
  sectionTitle: { fontSize: 17, fontWeight: "700" },
  alertCount: { paddingHorizontal: 7, paddingVertical: 2, borderRadius: 10 },
  alertCountText: { color: "#fff", fontSize: 11, fontWeight: "700" },

  forecastCard: { borderRadius: 16, borderWidth: 1, overflow: "hidden" },
  forecastRow: {
    flexDirection: "row", alignItems: "center", paddingVertical: 12, paddingHorizontal: 16,
  },
  forecastDivider: { height: 1, marginHorizontal: 16 },
  forecastDay: { fontSize: 13, width: 62 },
  forecastMiddle: { flex: 1, flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 8 },
  forecastDesc: { fontSize: 13, flex: 1 },
  forecastRight: { flexDirection: "row", gap: 6, alignItems: "center" },
  forecastTempMax: { fontSize: 15, fontWeight: "700" },
  forecastTempMin: { fontSize: 14 },

  forecastGrid: {
    flexDirection: "row", flexWrap: "wrap", gap: 10,
  },
  forecastGridCard: {
    flex: 1, minWidth: 110, borderRadius: 14, borderWidth: 1,
    padding: 14, alignItems: "center", gap: 8,
  },
  forecastGridDay: { fontSize: 12, fontWeight: "600" },
  forecastGridDesc: { fontSize: 11, textAlign: "center", lineHeight: 16 },
  forecastGridTemps: { flexDirection: "row", gap: 6, alignItems: "center" },
  forecastGridRain: { flexDirection: "row", alignItems: "center", gap: 4, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 4 },
  forecastGridRainText: { fontSize: 11, fontWeight: "600" },

  alertsGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  alertCard: { marginBottom: 8, borderRadius: 14, borderWidth: 1, padding: 14 },
  alertCardGrid: { flex: 1, minWidth: 200, marginBottom: 0 },
  alertTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 8 },
  alertSource: { fontSize: 12, fontWeight: "600" },
  alertTitle: { fontSize: 14, fontWeight: "700", marginBottom: 4 },
  alertArea: { fontSize: 12 },

  viewAllBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    marginBottom: 8, paddingVertical: 12,
    borderRadius: 12, borderWidth: 1, gap: 6,
  },
  viewAllText: { fontSize: 14, fontWeight: "600" },
});
