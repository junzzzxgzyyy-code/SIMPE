import React, { useState, useRef, useCallback, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  Platform,
  Animated,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { KeyboardAvoidingView as KAV } from "react-native-keyboard-controller";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Haptics from "expo-haptics";
import { fetch as expoFetch } from "expo/fetch";

import { useColors } from "@/hooks/useColors";
import { useResponsive } from "@/hooks/useResponsive";

const BASE_URL = `https://${process.env["EXPO_PUBLIC_DOMAIN"]}`;
const CONVERSATION_KEY = "weather_chat_conversation_id";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  createdAt: string;
}

const SUGGESTED_QUESTIONS = [
  "Apa itu El Nino dan dampaknya di Indonesia?",
  "Bagaimana membaca radar cuaca?",
  "Kapan musim hujan di Jakarta?",
  "Apa perbedaan badai tropis dan topan?",
  "Tips keselamatan saat banjir",
  "Apa itu La Nina?",
];

function TypingDot({ delay, color }: { delay: number; color: string }) {
  const anim = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.delay(delay),
        Animated.timing(anim, { toValue: -6, duration: 280, useNativeDriver: true }),
        Animated.timing(anim, { toValue: 0, duration: 280, useNativeDriver: true }),
        Animated.delay(400),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [anim, delay]);
  return (
    <Animated.View
      style={[styles.dot, { backgroundColor: color, transform: [{ translateY: anim }] }]}
    />
  );
}

export default function ChatScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { isWide, isDesktop, contentMaxWidth, horizontalPadding } = useResponsive();
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [streamingContent, setStreamingContent] = useState("");
  const [conversationId, setConversationId] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const flatListRef = useRef<FlatList>(null);

  const topInset = Platform.OS === "web" ? (isWide ? 0 : 67) : insets.top;
  const bottomInset = Platform.OS === "web" ? 16 : insets.bottom;

  useEffect(() => {
    initConversation();
  }, []);

  const initConversation = async () => {
    try {
      const stored = await AsyncStorage.getItem(CONVERSATION_KEY);
      if (stored) {
        const id = parseInt(stored);
        const res = await fetch(`${BASE_URL}/api/openai/conversations/${id}`);
        if (res.ok) {
          const data = (await res.json()) as { messages: Message[]; id: number };
          setConversationId(data.id);
          setMessages(data.messages.reverse());
          setLoading(false);
          return;
        }
      }
      await createNewConversation();
    } catch {
      await createNewConversation();
    }
  };

  const createNewConversation = async () => {
    try {
      const res = await fetch(`${BASE_URL}/api/openai/conversations`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: "Tanya Cuaca Indonesia" }),
      });
      if (res.ok) {
        const data = (await res.json()) as { id: number };
        setConversationId(data.id);
        await AsyncStorage.setItem(CONVERSATION_KEY, String(data.id));
      }
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  const sendMessage = useCallback(
    async (text: string) => {
      if (!text.trim() || !conversationId || isSending) return;

      const userMsg: Message = {
        id: `u-${Date.now()}`,
        role: "user",
        content: text.trim(),
        createdAt: new Date().toISOString(),
      };

      setMessages((prev) => [userMsg, ...prev]);
      setInputText("");
      setIsSending(true);
      setStreamingContent("");

      if (Platform.OS !== "web") {
        await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      }

      try {
        const response = await expoFetch(
          `${BASE_URL}/api/openai/conversations/${conversationId}/messages`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ content: text.trim() }),
          }
        );

        if (!response.ok || !response.body) throw new Error("Stream failed");

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let accumulated = "";

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value, { stream: true });
          const lines = chunk.split("\n");

          for (const line of lines) {
            if (line.startsWith("data: ")) {
              try {
                const parsed = JSON.parse(line.slice(6)) as {
                  content?: string;
                  done?: boolean;
                  error?: string;
                };
                if (parsed.content) {
                  accumulated += parsed.content;
                  setStreamingContent(accumulated);
                } else if (parsed.done) {
                  const assistantMsg: Message = {
                    id: `a-${Date.now()}`,
                    role: "assistant",
                    content: accumulated,
                    createdAt: new Date().toISOString(),
                  };
                  setMessages((prev) => [assistantMsg, ...prev]);
                  setStreamingContent("");
                }
              } catch {
                // skip malformed
              }
            }
          }
        }
      } catch {
        const errMsg: Message = {
          id: `e-${Date.now()}`,
          role: "assistant",
          content: "Maaf, terjadi kesalahan. Silakan coba lagi.",
          createdAt: new Date().toISOString(),
        };
        setMessages((prev) => [errMsg, ...prev]);
        setStreamingContent("");
      } finally {
        setIsSending(false);
      }
    },
    [conversationId, isSending]
  );

  const clearChat = useCallback(async () => {
    if (!conversationId) return;
    try {
      await fetch(`${BASE_URL}/api/openai/conversations/${conversationId}`, { method: "DELETE" });
      await AsyncStorage.removeItem(CONVERSATION_KEY);
      setMessages([]);
      await createNewConversation();
    } catch {
      // ignore
    }
  }, [conversationId]);

  const renderItem = ({ item }: { item: Message }) => {
    const isUser = item.role === "user";
    return (
      <View style={[styles.messageRow, isUser ? styles.userRow : styles.assistantRow]}>
        {!isUser && (
          <View style={[styles.aiAvatar, { backgroundColor: colors.primary }]}>
            <MaterialCommunityIcons name="weather-cloudy" size={18} color="#fff" />
          </View>
        )}
        <View
          style={[
            styles.bubble,
            isUser
              ? [styles.userBubble, { backgroundColor: colors.primary }]
              : [styles.assistantBubble, { backgroundColor: colors.card, borderColor: colors.border }],
            isWide && styles.bubbleWide,
          ]}
        >
          <Text style={[styles.bubbleText, { color: isUser ? "#fff" : colors.foreground }]}>
            {item.content}
          </Text>
        </View>
      </View>
    );
  };

  const maxWidthStyle = isWide
    ? { maxWidth: contentMaxWidth, alignSelf: "center" as const, width: "100%" as const }
    : {};

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <LinearGradient
        colors={["#0096c7", "#48cae4"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[styles.header, { paddingTop: topInset + 12, paddingHorizontal: horizontalPadding }]}
      >
        <View style={[styles.headerInner, maxWidthStyle]}>
          <View style={styles.headerRow}>
            <View style={styles.headerLeft}>
              <View style={styles.headerAvatar}>
                <MaterialCommunityIcons name="weather-lightning-rainy" size={22} color="#fff" />
              </View>
              <View>
                <Text style={styles.headerTitle}>AI Cuaca Indonesia</Text>
                <View style={styles.headerStatusRow}>
                  <View style={styles.statusDot} />
                  <Text style={styles.headerSub}>Online · GPT-5.2</Text>
                </View>
              </View>
            </View>
            <TouchableOpacity onPress={clearChat} style={styles.clearBtn}>
              <Ionicons name="trash-outline" size={18} color="rgba(255,255,255,0.85)" />
            </TouchableOpacity>
          </View>
        </View>
      </LinearGradient>

      {loading ? (
        <View style={[styles.loadingContainer, { backgroundColor: colors.background }]}>
          <ActivityIndicator color={colors.primary} size="large" />
          <Text style={[styles.loadingText, { color: colors.mutedForeground }]}>Menghubungkan ke AI...</Text>
        </View>
      ) : (
        <KAV behavior="padding" style={{ flex: 1 }} keyboardVerticalOffset={0}>
          <View style={[{ flex: 1 }, isWide && { alignItems: "center" }]}>
            <FlatList
              ref={flatListRef}
              data={messages}
              inverted
              keyExtractor={(item) => item.id}
              renderItem={renderItem}
              contentContainerStyle={[
                styles.flatListContent,
                isWide && { width: "100%", maxWidth: contentMaxWidth },
              ]}
              style={isWide ? { width: "100%", maxWidth: contentMaxWidth } : undefined}
              showsVerticalScrollIndicator={false}
              keyboardDismissMode="interactive"
              keyboardShouldPersistTaps="handled"
              ListHeaderComponent={
                streamingContent ? (
                  <View style={[styles.messageRow, styles.assistantRow]}>
                    <View style={[styles.aiAvatar, { backgroundColor: colors.primary }]}>
                      <MaterialCommunityIcons name="weather-cloudy" size={18} color="#fff" />
                    </View>
                    <View
                      style={[
                        styles.bubble,
                        styles.assistantBubble,
                        { backgroundColor: colors.card, borderColor: colors.border },
                        isWide && styles.bubbleWide,
                      ]}
                    >
                      <Text style={[styles.bubbleText, { color: colors.foreground }]}>{streamingContent}</Text>
                      <View style={[styles.typingDots, { marginTop: 6 }]}>
                        <TypingDot delay={0} color={colors.primary} />
                        <TypingDot delay={140} color={colors.primary} />
                        <TypingDot delay={280} color={colors.primary} />
                      </View>
                    </View>
                  </View>
                ) : isSending ? (
                  <View style={[styles.messageRow, styles.assistantRow]}>
                    <View style={[styles.aiAvatar, { backgroundColor: colors.primary }]}>
                      <MaterialCommunityIcons name="weather-cloudy" size={18} color="#fff" />
                    </View>
                    <View
                      style={[
                        styles.bubble,
                        styles.assistantBubble,
                        { backgroundColor: colors.card, borderColor: colors.border },
                      ]}
                    >
                      <View style={styles.typingDots}>
                        <TypingDot delay={0} color={colors.mutedForeground} />
                        <TypingDot delay={150} color={colors.mutedForeground} />
                        <TypingDot delay={300} color={colors.mutedForeground} />
                      </View>
                    </View>
                  </View>
                ) : null
              }
              ListFooterComponent={
                messages.length === 0 ? (
                  <View style={styles.suggestionsContainer}>
                    <View style={[styles.welcomeCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                      <View style={[styles.welcomeIconBg, { backgroundColor: colors.secondary }]}>
                        <MaterialCommunityIcons name="weather-lightning-rainy" size={40} color={colors.primary} />
                      </View>
                      <Text style={[styles.welcomeTitle, { color: colors.foreground }]}>
                        AI Cuaca Indonesia
                      </Text>
                      <Text style={[styles.welcomeDesc, { color: colors.mutedForeground }]}>
                        Tanyakan apa saja tentang cuaca, iklim, bencana alam, atau fenomena meteorologi di Indonesia.
                      </Text>
                    </View>
                    <Text style={[styles.suggestLabel, { color: colors.mutedForeground }]}>Pertanyaan populer:</Text>
                    <View style={isDesktop ? styles.suggestGrid : undefined}>
                      {SUGGESTED_QUESTIONS.map((q) => (
                        <TouchableOpacity
                          key={q}
                          style={[
                            styles.suggestionBtn,
                            isDesktop && styles.suggestionBtnGrid,
                            { backgroundColor: colors.card, borderColor: colors.border },
                          ]}
                          onPress={() => sendMessage(q)}
                        >
                          <Text style={[styles.suggestionText, { color: colors.foreground }]}>{q}</Text>
                          <Ionicons name="arrow-up-circle" size={18} color={colors.primary} />
                        </TouchableOpacity>
                      ))}
                    </View>
                  </View>
                ) : null
              }
            />

            <View
              style={[
                styles.inputContainer,
                {
                  backgroundColor: colors.background,
                  borderTopColor: colors.border,
                  paddingBottom: bottomInset + 8,
                  paddingHorizontal: horizontalPadding,
                },
                isWide && { width: "100%", maxWidth: contentMaxWidth },
              ]}
            >
              <View
                style={[
                  styles.inputRow,
                  { backgroundColor: colors.card, borderColor: colors.border },
                ]}
              >
                <TextInput
                  value={inputText}
                  onChangeText={setInputText}
                  placeholder="Tanya tentang cuaca Indonesia..."
                  placeholderTextColor={colors.mutedForeground}
                  style={[styles.input, { color: colors.foreground }]}
                  multiline
                  maxLength={1000}
                  returnKeyType="send"
                  blurOnSubmit={false}
                  onSubmitEditing={() => {
                    if (inputText.trim()) sendMessage(inputText);
                  }}
                />
                <TouchableOpacity
                  onPress={() => sendMessage(inputText)}
                  disabled={!inputText.trim() || isSending}
                  style={[
                    styles.sendBtn,
                    {
                      backgroundColor:
                        inputText.trim() && !isSending ? colors.primary : colors.muted,
                    },
                  ]}
                >
                  <Ionicons
                    name="send"
                    size={18}
                    color={inputText.trim() && !isSending ? "#fff" : colors.mutedForeground}
                  />
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </KAV>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingBottom: 16 },
  headerInner: {},
  headerRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  headerLeft: { flexDirection: "row", alignItems: "center", gap: 12 },
  headerAvatar: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: "rgba(255,255,255,0.2)",
    alignItems: "center", justifyContent: "center",
  },
  headerTitle: { fontSize: 17, fontWeight: "700", color: "#fff" },
  headerStatusRow: { flexDirection: "row", alignItems: "center", gap: 5, marginTop: 2 },
  statusDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: "#4ade80" },
  headerSub: { fontSize: 12, color: "rgba(255,255,255,0.8)" },
  clearBtn: {
    width: 38, height: 38, borderRadius: 19,
    backgroundColor: "rgba(255,255,255,0.15)",
    alignItems: "center", justifyContent: "center",
  },

  loadingContainer: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12 },
  loadingText: { fontSize: 14 },

  flatListContent: { paddingHorizontal: 16, paddingVertical: 16, flexGrow: 1 },

  messageRow: { flexDirection: "row", marginBottom: 14, gap: 8 },
  userRow: { justifyContent: "flex-end" },
  assistantRow: { justifyContent: "flex-start", alignItems: "flex-end" },

  aiAvatar: {
    width: 34, height: 34, borderRadius: 17,
    alignItems: "center", justifyContent: "center",
    flexShrink: 0, marginBottom: 4,
  },
  bubble: { maxWidth: "78%", padding: 13, borderRadius: 18 },
  bubbleWide: { maxWidth: "65%" },
  userBubble: { borderBottomRightRadius: 4 },
  assistantBubble: { borderWidth: 1, borderBottomLeftRadius: 4 },
  bubbleText: { fontSize: 14, lineHeight: 22 },

  typingDots: { flexDirection: "row", gap: 5, padding: 4 },
  dot: { width: 8, height: 8, borderRadius: 4 },

  suggestionsContainer: { paddingVertical: 8, gap: 10 },
  welcomeCard: {
    borderRadius: 18, borderWidth: 1, padding: 24,
    alignItems: "center", gap: 10, marginBottom: 6,
  },
  welcomeIconBg: {
    width: 80, height: 80, borderRadius: 40,
    alignItems: "center", justifyContent: "center", marginBottom: 4,
  },
  welcomeTitle: { fontSize: 20, fontWeight: "700" },
  welcomeDesc: { fontSize: 14, textAlign: "center", lineHeight: 22 },
  suggestLabel: { fontSize: 12, fontWeight: "600", marginTop: 4 },
  suggestGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  suggestionBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    borderRadius: 12, borderWidth: 1, padding: 13, gap: 10,
  },
  suggestionBtnGrid: { flex: 1, minWidth: 220 },
  suggestionText: { fontSize: 13, flex: 1, lineHeight: 18 },

  inputContainer: { borderTopWidth: 1, paddingTop: 10 },
  inputRow: {
    flexDirection: "row", alignItems: "flex-end", borderRadius: 26,
    borderWidth: 1, paddingLeft: 16, paddingRight: 5, paddingVertical: 5, gap: 8,
  },
  input: { flex: 1, fontSize: 15, maxHeight: 120, paddingVertical: 8, minHeight: 38 },
  sendBtn: {
    width: 40, height: 40, borderRadius: 20,
    alignItems: "center", justifyContent: "center",
  },
});
