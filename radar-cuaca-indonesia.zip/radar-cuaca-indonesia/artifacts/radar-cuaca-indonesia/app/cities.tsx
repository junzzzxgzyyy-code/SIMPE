import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  TextInput,
  Platform,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";

import { useColors } from "@/hooks/useColors";
import { useWeatherContext } from "@/context/WeatherContext";
import { INDONESIA_CITIES, type City } from "@/constants/cities";

export default function CitiesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { selectedCity, setSelectedCity } = useWeatherContext();
  const [search, setSearch] = useState("");

  const topInset = Platform.OS === "web" ? 67 : insets.top;
  const bottomInset = Platform.OS === "web" ? 34 : insets.bottom;

  const filtered = INDONESIA_CITIES.filter(
    (c) =>
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.province.toLowerCase().includes(search.toLowerCase())
  );

  const handleSelect = async (city: City) => {
    await setSelectedCity(city);
    await Haptics.selectionAsync();
    router.back();
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: topInset + 12, backgroundColor: colors.background, borderBottomColor: colors.border }]}>
        <View style={styles.headerRow}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <Ionicons name="arrow-back" size={22} color={colors.foreground} />
          </TouchableOpacity>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>Pilih Kota</Text>
          <View style={{ width: 40 }} />
        </View>
        <View style={[styles.searchBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Ionicons name="search" size={18} color={colors.mutedForeground} />
          <TextInput
            value={search}
            onChangeText={setSearch}
            placeholder="Cari kota atau provinsi..."
            placeholderTextColor={colors.mutedForeground}
            style={[styles.searchInput, { color: colors.foreground }]}
          />
          {search.length > 0 && (
            <TouchableOpacity onPress={() => setSearch("")}>
              <Ionicons name="close-circle" size={18} color={colors.mutedForeground} />
            </TouchableOpacity>
          )}
        </View>
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(item) => item.name}
        contentContainerStyle={{ paddingVertical: 8, paddingBottom: bottomInset + 20 }}
        renderItem={({ item }) => {
          const isSelected = item.name === selectedCity.name;
          return (
            <TouchableOpacity
              onPress={() => handleSelect(item)}
              style={[
                styles.cityItem,
                {
                  borderBottomColor: colors.border,
                  backgroundColor: isSelected ? colors.secondary : "transparent",
                },
              ]}
            >
              <View style={styles.cityItemLeft}>
                <Ionicons
                  name={isSelected ? "location" : "location-outline"}
                  size={20}
                  color={isSelected ? colors.primary : colors.mutedForeground}
                />
                <View>
                  <Text style={[styles.cityName, { color: colors.foreground }]}>{item.name}</Text>
                  <Text style={[styles.cityProvince, { color: colors.mutedForeground }]}>{item.province}</Text>
                </View>
              </View>
              {isSelected && <Ionicons name="checkmark" size={20} color={colors.primary} />}
            </TouchableOpacity>
          );
        }}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1 },
  headerRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 12 },
  backBtn: { width: 40, height: 40, alignItems: "center", justifyContent: "center" },
  headerTitle: { fontSize: 18, fontWeight: "700" },
  searchBox: {
    flexDirection: "row", alignItems: "center", gap: 10,
    borderRadius: 12, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 10,
  },
  searchInput: { flex: 1, fontSize: 15 },
  cityItem: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingVertical: 14, paddingHorizontal: 20, borderBottomWidth: 1,
  },
  cityItemLeft: { flexDirection: "row", alignItems: "center", gap: 12 },
  cityName: { fontSize: 15, fontWeight: "600" },
  cityProvince: { fontSize: 12, marginTop: 2 },
});
