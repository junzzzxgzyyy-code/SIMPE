# Radar Cuaca Indonesia

## Overview

Aplikasi mobile radar cuaca komprehensif untuk Indonesia, dibangun dengan Expo (React Native) dan Express API server.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Mobile**: Expo / React Native (expo-router)
- **Backend**: Express 5 + TypeScript
- **Database**: PostgreSQL + Drizzle ORM
- **AI**: OpenAI GPT-5.2 (via Replit AI Integrations)
- **Weather Data**: Open-Meteo (free, open-source)
- **Map**: Windy.com embed (live radar maps)
- **Validation**: Zod (zod/v4), drizzle-zod

## Features

- **Cuaca Real-time**: Suhu, kelembapan, angin, UV index, tekanan, tutupan awan untuk 24+ kota Indonesia
- **Prakiraan 7 Hari**: Suhu max/min, peluang hujan, deskripsi cuaca harian
- **Peta Live Radar**: Integrasi Windy.com dengan layer angin, awan, hujan, suhu, tekanan
- **Peringatan Cuaca**: Dari BMKG dan BPBD dengan level: Info, Siaga, Waspada, Bahaya
- **Skala Badai**: Informasi tingkat badai tropis & subtropis (TD, TS, Ty 1-5)
- **AI Chat**: Asisten cuaca Indonesia berbasis GPT-5.2 dengan percakapan persisten
- **Pilih Kota**: 24+ kota di seluruh Indonesia

## Key Commands

- `pnpm --filter @workspace/api-server run dev` — run API server
- `pnpm --filter @workspace/radar-cuaca-indonesia run dev` — run Expo app
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks
- `pnpm --filter @workspace/db run push` — push DB schema changes

## Architecture

- `artifacts/radar-cuaca-indonesia/` — Expo mobile app
- `artifacts/api-server/` — Express API server (weather routes + OpenAI routes)
- `lib/db/` — PostgreSQL schema (conversations, messages tables)
- `lib/integrations-openai-ai-server/` — OpenAI server integration
- `lib/api-client-react/` — Generated API hooks (React Query)
